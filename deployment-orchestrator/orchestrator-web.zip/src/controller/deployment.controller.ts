import { DeploymentOperation, DeploymentsDeleteOptionalParams } from '@azure/arm-resources';
import {
    Controller,
    Get,
    Param,
    Put,
    Body,
    Post,
    UseInterceptors,
    UploadedFiles,
    UploadedFile,
    Res,
    Header,
    Delete,
    Query,
    BadRequestException,
    HttpException,
    HttpStatus,
} from '@nestjs/common';
import { response } from 'express';
import { CreateDeploymentDto } from 'src/models/create-deployment.dto';
import { DeploymentService, IDeploymentResult } from 'src/service/deployment.service';

@Controller('deployments')
export class DeploymentController {
    constructor(private readonly deploymentService: DeploymentService) {}

    @Get('/:resourceGroup/:deploymentName')
    async getDeployments(
                @Param('resourceGroup') resourceGroup: string, 
                @Param('deploymentName') deploymentName: string) {
        console.log(`calling getDeployments with resourceGroup - ${resourceGroup} and deploymentName - ${deploymentName}`)
        let responseMessage: IDeploymentResult;
        const success: boolean = true;
        let result: DeploymentOperation[];
        try {
            result = await this.deploymentService.listDeploymentsOperations(resourceGroup, deploymentName);
        }
        catch (error) {
            console.log(error);
        }

        responseMessage = {
            success: success,
            deploymentOperations: result
        }

        return responseMessage;
    }

    @Post()
    async create(@Body() createDeployment: CreateDeploymentDto) {
        //todo: change to load from environment variables
        
        const params: Record<string, unknown> = {
            "storagePrefix": {
                "value": "devstore"
            },
            "storageSKU": {
                "value": "Standard_LRS"
            },
            "appServicePlanName": {
                "value": "devplan"
            },
            "webAppName": {
                "value": "devapp"
            },
            "resourceTags": {
                "value": {
                  "Environment": "Dev",
                  "Project": "Tutorial"
                }
              }
        };
        return this.deploymentService.createOrUpdateDeploymant(
            createDeployment.templateUri, 
            createDeployment.parametersUri, 
            params,
            createDeployment.resourceGroup, 
            createDeployment.deploymentName);
    }
}