import { Guid } from 'guid-typescript';
import { Injectable, OnModuleInit } from '@nestjs/common';
import { ClientSecretCredential, DefaultAzureCredential } from "@azure/identity";
import * as msRest from "@azure/ms-rest-js";
import {
    Deployment,
    DeploymentOperation,
    ExportTemplateRequest,
    GenericResource,
    ParametersLink,
    ResourceGroup,
    ResourceGroupPatchable,
    ResourceManagementClient,
    ResourcesMoveInfo,
    ScopedDeployment,
    TagsPatchResource,
    TagsResource,
    TemplateLink,
} from "@azure/arm-resources";
import { ManagementGroupsAPI } from "@azure/arm-managementgroups";
import { AzureDeploymentManager, AzureDeploymentManagerModels, AzureDeploymentManagerMappers } from "@azure/arm-deploymentmanager";
import { DeploymentParams, IDeploymentParams, DeploymentParamsPropsArray, propsArray } from 'src/models/deployment-params';
import * as msRestNodeAuth from "@azure/ms-rest-nodeauth";
import { stringify } from 'querystring';

export interface IDeploymentResult {
    success: boolean;
    deploymentOperations: Array<DeploymentOperation>;
}

@Injectable()
export class DeploymentService implements OnModuleInit {
    resourceClient: ResourceManagementClient
    managementGroupsApi: ManagementGroupsAPI;

    public constructor() {
        const tenantId = process.env.DEPLOYMENT_ORCHESTRATOR_TENANT_ID;
        const clientId = process.env.DEPLOYMENT_ORCHESTRATOR_CLIENT_ID;
        const clientSecret = process.env.DEPLOYMENT_ORCHESTRATOR_CLIENT_SECRET;
        const subscriptionId = process.env.DEPLOYMENT_ORCHESTRATOR_SUBSCRIPTION_ID;

        console.log(`Inside DeploymentService constructor with a tenantId of ${tenantId}`);
        console.log(`Inside DeploymentService constructor with a clientId of ${clientId}`);
        console.log(`Inside DeploymentService constructor with a clientSecret of ${clientSecret}`);
        console.log(`Inside DeploymentService constructor with a subscriptionId of ${subscriptionId}`);

        const credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
        this.resourceClient = new ResourceManagementClient(credential, subscriptionId);
    }

    public deploy(armTemplate: string) {
        console.log('calling deploy in DeploymentService');
    }

    private loadParamsRecords() : Record<string, unknown> {
        let paramsRecord: Record<string, unknown> = {};
        for (let item of propsArray) {
            if (typeof process.env[item] == "string") {
                paramsRecord[item] = {
                    "value": process.env[item]
                };
            }
        }
        return paramsRecord; 
    }

    private loadParams() : DeploymentParams {
        const deploymentParams = new DeploymentParams();
        //const propsArray: DeploymentParamsPropsArray = Object.keys(deploymentParams) as DeploymentParamsPropsArray;
        for (let item of propsArray) {
            if (process.env[item]) {
                deploymentParams[item] = {
                    "value": process.env[item]
                };
            }
        }
        return deploymentParams;
    }

    public async listDeploymentsOperations(resourceGroupName: string, deploymentName: string) {
        const deploymentOperations: Array<DeploymentOperation> = [];
        for await (const item of this.resourceClient.deploymentOperations.list(
            resourceGroupName,
            deploymentName
        )) {
            deploymentOperations.push(item);
        }
        return deploymentOperations;
    }

    public async createOrUpdateDeploymant(
        templateUri: string, 
        parametersUri: string, 
        parameters: Record<string, unknown>,
        resourceGroupName: string, 
        deploymentName: string) {

        const mode = 'Incremental';
        const templateLink: TemplateLink = {
            uri: templateUri
        }
        const parametersLink: ParametersLink = {
            uri: parametersUri
        }

        const deployment: Deployment = {
            properties: {
                mode: mode,
                templateLink: templateLink,
                //parametersLink: parametersLink,
                parameters: parameters
            }
        }

        const createResult = await this.resourceClient.deployments.beginCreateOrUpdateAndWait(
            resourceGroupName,
            deploymentName,
            deployment
        );

        return createResult
    }

    async onModuleInit() {
        console.log(`The deployment service has been initialized`);
        const resourceGroup = process.env.DEPLOYMENT_RESOURCE_GROUP;
        const deploymentName = process.env.DEPLOYMENT_NAME;
        const deployments = await this.listDeploymentsOperations(resourceGroup, deploymentName);
        for (const deploymentOperation of deployments) {
            console.log(JSON.stringify(deploymentOperation));
        }
        console.log(`The type of process.env.HARK is ${typeof process.env.HARK}`);
        console.log(`The type of process.env.DEPLOYMENT_NAME is ${typeof process.env.DEPLOYMENT_NAME}`);
        console.log(`Inisde onModuleInit - ${deployments}`);
        //const deploymentParams = this.loadParams();
        //console.log(`deploymentParams - ${JSON.stringify(deploymentParams)}`);

        console.log(`Kicking of deployment.......\n`);
        //const params = deploymentParams as IDeploymentParams;
        
        /*const params: Record<string, unknown> = {
            "storagePrefix": {
                "value": "devstore"
            },
            "storageSKU": {
                "value": "Standard_LRS"
            },
            "appServicePlanName": {
                "value": "devplan"
            },
            "webAppName": {
                "value": "devapp"
            },
            "resourceTags": {
                "value": {
                  "Environment": "Dev",
                  "Project": "Tutorial"
                }
              }
        }; */

        const paramsRecord = this.loadParamsRecords();

        const deployResult = await this.createOrUpdateDeploymant(
            //"https://raw.githubusercontent.com/bobjac/react/master/arm-templates/mainTemplate.json", 
            "https://neudipdevdeployment.blob.core.windows.net/packages/1-7-4/mainTemplate.json?sp=r&st=2022-06-22T22:16:18Z&se=2032-06-23T06:16:18Z&spr=https&sv=2021-06-08&sr=c&sig=KLB%2FQ1OHNX6gMeSq1jPiIWMLDcTiUf5tv2820UONCmU%3D",
            "", 
            paramsRecord, 
            "DIP", 
            "bobjacdip2_222");

        console.log(`deployResult - ${JSON.stringify(deployResult)}`);
    }
}
